package hameez.com.databaselabs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Hamzeen. H. on 9/14/15.
 */
public class MainListView extends Activity {

    private static final String APP_TAG = MainListView.class.getSimpleName();
    private Button btnNew;
    private ListView listView;

    private static List<User> lstUsers = new ArrayList<User>();
    private static UserDataSource userDS;
    private ArrayAdapter<User> dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        btnNew = (Button) findViewById(R.id.btnNew);
        btnNew.setOnClickListener(newBtnListener);

        listView = (ListView) findViewById(R.id.listView);

        userDS = new UserDataSource(this);
        dataAdapter = new ArrayAdapter<User>(this, R.layout.clikctime_list, getUsers());

        listView.setAdapter(dataAdapter);
        listView.setTextFilterEnabled(true);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                final User temp = (User) parent.getItemAtPosition(position);//position += 1;
                Log.d(APP_TAG, "email: "+ temp.getEmail());
                Util.showToast(getApplicationContext(), "username: "+ temp.getUserName());
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        dataAdapter.clear();
        dataAdapter.addAll(getUsers());
    }

    private final View.OnClickListener newBtnListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent newUserIntent = new Intent(MainListView.this, NewUserView.class);
            MainListView.this.startActivity(newUserIntent);
        }
    };

    private List<User> getUsers() {
        lstUsers.clear();

        userDS.open();
        if(userDS.getAllUsers()!=null && userDS.getAllUsers().size() > 0) {
            lstUsers = userDS.getAllUsers();
        }
        userDS.close();
        return lstUsers;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_view, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
