package hameez.com.databaselabs;

/**
 * Created by admin on 9/15/15.
 * This class holds all the constants used in the app.
 */
public class Constants {

    public class DBConstants {

        public static final String NULL_VALUE_KEY = "NULL";

        //Table for user_details which stores user details
        public static final String TABLE_USER = "user";
        public static final String COLUMN_ID = "user_id";
        public static final String COLUMN_USERNAME = "user_name";
        public static final String COLUMN_EMAIL = "email";

        // Database Version & its FileName
        public static final String DATABASE_NAME = "user.db";
        public static final int DATABASE_VERSION = 1;
    }

    public static final String APP_NAME = "User List";
    public static final String BTN_ADD_NEW = "Add New";
}
