package hameez.com.databaselabs;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Hamzeen. H. on 9/14/15.
 */
public class Util {

    private static int counter = 0;

    public static String getFormattedTime() {
        Calendar cal = Calendar.getInstance();
        DateFormat formatter = new SimpleDateFormat("KK:mm:ss a");
        counter++;
        return counter+". "+formatter.format(cal.getTime());
    }

    public static void showToast(Context context, String message) {
        Toast toast = Toast.makeText(context, message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP, 353, 300);
        toast.show();
    }
}
