package hameez.com.databaselabs;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.SyncStateContract;

/**
 * Created by Hamzeen. H. on 9/15/15.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private Context ctx;
    public DatabaseHelper(Context context) {
        super(context, Constants.DBConstants.DATABASE_NAME, null, Constants.DBConstants.DATABASE_VERSION);
        ctx = context;
    }

    /*
     * Schema: User (user_id,user_name,email)
     */
    //SQL statement to create the user_details table
    private static final String CREATE_USER_TABLE = "CREATE TABLE "
            + Constants.DBConstants.TABLE_USER+ "("
            + Constants.DBConstants.COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
            + Constants.DBConstants.COLUMN_USERNAME + " TEXT , "
            + Constants.DBConstants.COLUMN_EMAIL +  " TEXT NOT NULL);";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        Util.showToast(ctx, "DB Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ Constants.DBConstants.TABLE_USER);
        onCreate(db);
    }
}
