package hameez.com.databaselabs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 9/15/15.
 */
public class UserDataSource {

    private String TAG = UserDataSource.class.getSimpleName();
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public UserDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long createUser(String userName, String email) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(Constants.DBConstants.COLUMN_USERNAME, userName);
        contentValues.put(Constants.DBConstants.COLUMN_EMAIL, email);

        long row = database.insert(Constants.DBConstants.TABLE_USER, null, contentValues);
        Log.d(TAG, "New User Inserted");

        return row;
    }

    public List<User> getAllUsers() {
        List<User> users = null;

        if (database != null) {
            Cursor cursor = database.rawQuery("SELECT * FROM " + Constants.DBConstants.TABLE_USER, null);
            if (cursor.moveToFirst()){
                users = new ArrayList<User>(cursor.getCount());

                while (cursor.isAfterLast() == false){
                    User temp = new User();
                    temp.setUserName(cursor.getString(cursor.getColumnIndex(Constants.DBConstants.COLUMN_USERNAME)));
                    temp.setEmail(cursor.getString(cursor.getColumnIndex(Constants.DBConstants.COLUMN_EMAIL)));

                    users.add(temp);
                    cursor.moveToNext();
                }
            }
        }
        return users;
    }
}
