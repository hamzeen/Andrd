package hameez.com.databaselabs;

/**
 * Created by Hamzeen. H. on 9/15/15.
 * A bean class to represent User.
 */
public class User {

    public int id;

    public String userName;

    public String email;

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return this.userName + ": "+this.email;
    }
}
