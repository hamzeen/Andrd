package hameez.com.databaselabs;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class NewUserView extends ActionBarActivity {

    private EditText txtUserName,txtEmail;
    private Button btnCreate;
    private static UserDataSource userDS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_new_user_view);

        btnCreate = (Button) findViewById(R.id.btn_create);
        txtUserName = (EditText) findViewById(R.id.txt_username);
        txtEmail = (EditText) findViewById(R.id.txt_email);
        userDS = new UserDataSource(this);

        btnCreate.setOnClickListener(createBtnListener);
    }

    private final View.OnClickListener createBtnListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            // add a new user
            if(txtEmail.getText().toString().trim()!=null && !txtEmail.getText().toString().trim().equals("")
                    && txtUserName.getText().toString().trim()!=null && !txtUserName.getText().toString().trim().equals("")) {
                userDS.open();
                long result = userDS.createUser(txtUserName.getText().toString().trim(),txtEmail.getText().toString().trim());
                userDS.close();
            } else {
                // show a toast asking to provide valid info
            }
            finish();
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_new_user_view, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
